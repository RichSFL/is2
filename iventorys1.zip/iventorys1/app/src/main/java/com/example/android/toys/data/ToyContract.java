/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.toys.data;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * API Contract for the Toys app.
 */
public final class ToyContract {

    /**
     * Inner class that defines constant values for the toys database table.
     * Each entry in the table represents a single toy.
     */
    public static final String CONTENT_AUTHORITY = "com.example.android.toys";
    public static final Uri BASE_CONTENT_URI = Uri.parse( "content://" + CONTENT_AUTHORITY );
    public static final String PATH_TOYS = "toys";
    // To prevent someone from accidentally instantiating the contract class,
    // give it an empty constructor.
    private ToyContract() {
    }

    public static final class ToyEntry implements BaseColumns {


        public static final Uri CONTENT_URI = Uri.withAppendedPath( BASE_CONTENT_URI, PATH_TOYS );

        public static final String CONTENT_LIST_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_TOYS;

        public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_TOYS;


        /**
         * Name of database table for toys
         */
        public final static String TABLE_NAME = "toys";

        /**
         * Unique ID number for the toy (only for use in the database table).
         * <p>
         * Type: INTEGER
         */
        public final static String _ID = BaseColumns._ID;

        /**
         * Name of the toy.
         * <p>
         * Type: TEXT
         */
        public final static String COLUMN_TOY_NAME = "names";

        /**
         * Price of the toy.
         * <p>
         * Type: TEXT
         */
        public final static String COLUMN_TOY_PRICE = "price";


        /**
         * Price of the toy.
         * <p>
         * The only possible values are {@link #WAREHOUSE_EASTCOAST}, {@link #WAREHOUSE_WESTCOAST},
         * or {@link #WAREHOUSE_MIDWEST}.
         * <p>
         * Type: INTEGER
         */
        public final static String COLUMN_TOY_WH = "warehouse";

        /**
         * Weight of the toy.
         * <p>
         * Type: INTEGER
         */
        public final static String COLUMN_TOY_QTY = "quantity";

        /**
         * Possible values for the warehouse of the toy.
         */
        public static final int WAREHOUSE_EASTCOAST = 0;
        public static final int WAREHOUSE_WESTCOAST = 1;
        public static final int WAREHOUSE_MIDWEST = 2;
        /**
         * Provider for the toy.
         * <p>
         * Type: TEXT
         */
        public final static String COLUMN_TOY_PROVIDER = "provider";
        /**
         * Phone number for the toy provider.
         * <p>
         * Type: TEXT
         */
        public final static String COLUMN_TOY_PHONE = "phone";

        public static boolean isValidWarehouse(int warehouse) {
            if (warehouse == WAREHOUSE_EASTCOAST || warehouse == WAREHOUSE_WESTCOAST || warehouse == WAREHOUSE_MIDWEST) {
                return true;
            }
            return false;
        }
    }

}

