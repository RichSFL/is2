/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.toys.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import com.example.android.toys.data.ToyContract.ToyEntry;


/**
 * {@link ContentProvider} for Pets app.
 */
public class ToysProvider extends ContentProvider {

    /**
     * Tag for the log messages
     */
    public static final String LOG_TAG = ToysProvider.class.getSimpleName();


    private static final int TOYS = 100;

    private static final int TOY_ID = 101;

    private static final UriMatcher sUriMatcher = new UriMatcher( UriMatcher.NO_MATCH );

    static {
        sUriMatcher.addURI( ToyContract.CONTENT_AUTHORITY, ToyContract.PATH_TOYS, TOYS );
        sUriMatcher.addURI( ToyContract.CONTENT_AUTHORITY, ToyContract.PATH_TOYS + "/#", TOY_ID );
    }

    private ToyDbHelper mDbHelper; //database helper object


    /**
     * Initialize the provider and the database helper object.
     */
    @Override
    public boolean onCreate() {

        mDbHelper = new ToyDbHelper( getContext() );
        return true;
    }

    /**
     * Perform the query for the given URI. Use the given projection, selection, selection arguments, and sort order.
     */
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        // Get readable database
        SQLiteDatabase database = mDbHelper.getReadableDatabase();

        // This cursor will hold the result of the query
        Cursor cursor;

        // Figure out if the URI matcher can match the URI to a specific code
        int match = sUriMatcher.match( uri );
        switch (match) {
            case TOYS:

                cursor = database.query( ToyEntry.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder );
                break;
            case TOY_ID:

                selection = ToyEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf( ContentUris.parseId( uri ) )};

                // This will perform a query on the pets table where the _id equals 3 to return a
                // Cursor containing that row of the table.
                cursor = database.query( ToyEntry.TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder );
                break;
            default:
                throw new IllegalArgumentException( "Cannot query unknown URI " + uri );
        }
        cursor.setNotificationUri( getContext().getContentResolver(), uri );
        return cursor;
    }

    /**
     * Insert new data into the provider with the given ContentValues.
     */
    @Override
    public Uri insert(Uri uri, ContentValues contentValues) {
        final int match = sUriMatcher.match( uri );
        switch (match) {
            case TOYS:
                return insertToy( uri, contentValues );
            default:
                throw new IllegalArgumentException( "Insertion is not supported for " + uri );
        }
    }

    /**
     * Insert a toyinto the database with the given content values. Return the new content URI
     * for that specific row in the database.
     */
    private Uri insertToy(Uri uri, ContentValues values) {

        // Check that the name is not null
        String name = values.getAsString( ToyEntry.COLUMN_TOY_NAME );
        if (name == null) {
            throw new IllegalArgumentException( "Toy requires a name" );
        }

        // Check that the price is not null
        Integer price = values.getAsInteger( ToyEntry.COLUMN_TOY_PRICE );
        if (price == null) {
            throw new IllegalArgumentException( "Toy requires a price" );
        }

        // Check that the warehouse is valid
        Integer warehouse = values.getAsInteger( ToyEntry.COLUMN_TOY_WH );
        if (warehouse == null || !ToyEntry.isValidWarehouse( warehouse )) {
            throw new IllegalArgumentException( "Toy requires valid warehouse" );
        }

        // If the quantity is provided, check that it's greater than or equal to 0 units
        Integer quantity = values.getAsInteger( ToyEntry.COLUMN_TOY_QTY );
        if (quantity != null && quantity < 0) {
            throw new IllegalArgumentException( "Toy requires valid quantity" );
        }

        // Check that the provider name is not null
        String provider = values.getAsString( ToyEntry.COLUMN_TOY_PROVIDER );
        if (provider == null) {
            throw new IllegalArgumentException( "Provider requires a name" );
        }

        // Check that the name is not null
        Integer phone = values.getAsInteger( ToyEntry.COLUMN_TOY_PHONE );
        if (phone == null) {
            throw new IllegalArgumentException( "Provider requires a phone number" );
        }

// Get writeable database
        SQLiteDatabase database = mDbHelper.getWritableDatabase();
        long id = database.insert( ToyEntry.TABLE_NAME, null, values );
        if (id == -1) {
            Log.e( LOG_TAG, "Failed to insert row for " + uri );
            return null;
        }
        // Notify all listeners that the data has changed for the pet content URI
        getContext().getContentResolver().notifyChange( uri, null );
        // Once we know the ID of the new row in the table,
        // return the new URI with the ID appended to the end of it
        return ContentUris.withAppendedId( uri, id );
    }

    /**
     * Updates the data at the given selection and selection arguments, with the new ContentValues.
     */
    @Override
    public int update(Uri uri, ContentValues contentValues, String selection, String[] selectionArgs) {
        final int match = sUriMatcher.match( uri );
        switch (match) {
            case TOYS:
                return updateToy( uri, contentValues, selection, selectionArgs );
            case TOY_ID:

                selection = ToyEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf( ContentUris.parseId( uri ) )};
                return updateToy( uri, contentValues, selection, selectionArgs );
            default:
                throw new IllegalArgumentException( "Update is not supported for " + uri );
        }

    }

    private int updateToy(Uri uri, ContentValues values, String selection, String[] selectionArgs) {

        // check that the name value is not null.
        if (values.containsKey( ToyEntry.COLUMN_TOY_NAME )) {
            String name = values.getAsString( ToyEntry.COLUMN_TOY_NAME );
            if (name == null) {
                throw new IllegalArgumentException( "Toy requires a name" );
            }
        }

        // check that the price value is valid.
        if (values.containsKey( ToyEntry.COLUMN_TOY_PRICE )) {
            // Check that the price is greater than 0
            Integer price = values.getAsInteger( ToyEntry.COLUMN_TOY_PRICE );
            if (price != null && price < 0) {
                throw new IllegalArgumentException( "Toy requires valid price" );
            }
        }

        // check that the warehouse value is valid.
        if (values.containsKey( ToyEntry.COLUMN_TOY_WH )) {
            Integer warehouse = values.getAsInteger( ToyEntry.COLUMN_TOY_WH );
            if (warehouse == null || !ToyEntry.isValidWarehouse( warehouse )) {
                throw new IllegalArgumentException( "Toy requires valid warehouse" );
            }
        }

        // check that the quantity value is valid.
        if (values.containsKey( ToyEntry.COLUMN_TOY_QTY )) {
            // Check that the price is greater than or equal to 0 UNITS
            Integer quantity = values.getAsInteger( ToyEntry.COLUMN_TOY_QTY );
            if (quantity != null && quantity < 0) {
                throw new IllegalArgumentException( "Toy requires valid quantity" );
            }
        }

        // check that the provider name value is not null.
        if (values.containsKey( ToyEntry.COLUMN_TOY_PROVIDER )) {
            String provider = values.getAsString( ToyEntry.COLUMN_TOY_PROVIDER );
            if (provider == null) {
                throw new IllegalArgumentException( "Provider requires a name" );
            }
        }

        // check that the phone value is valid.
        if (values.containsKey( ToyEntry.COLUMN_TOY_PHONE )) {
            // Check that the phone is not null
            Integer phone = values.getAsInteger( ToyEntry.COLUMN_TOY_PHONE );
            if (phone != null && phone < 0) {
                throw new IllegalArgumentException( "Provider requires valid phone" );
            }
        }

        // If there are no values to update, then don't try to update the database
        if (values.size() == 0) {
            return 0;
        }


// Otherwise, get writeable database to update the data
        SQLiteDatabase database = mDbHelper.getWritableDatabase();

        // Perform the update on the database and get the number of rows affected
        int rowsUpdated = database.update( ToyEntry.TABLE_NAME, values, selection, selectionArgs );

        // If 1 or more rows were updated, then notify all listeners that the data at the
        // given URI has changed
        if (rowsUpdated != 0) {
            getContext().getContentResolver().notifyChange( uri, null );
        }

        // Return the number of rows updated
        return rowsUpdated;
    }


    /**
     * Delete the data at the given selection and selection arguments.
     */
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // Get writeable database
        SQLiteDatabase database = mDbHelper.getWritableDatabase();

        // Track the number of rows that were deleted
        int rowsDeleted;

        final int match = sUriMatcher.match( uri );
        switch (match) {
            case TOYS:
                // Delete all rows that match the selection and selection args
                rowsDeleted = database.delete( ToyEntry.TABLE_NAME, selection, selectionArgs );
                break;
            case TOY_ID:
                // Delete a single row given by the ID in the URI
                selection = ToyEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf( ContentUris.parseId( uri ) )};
                rowsDeleted = database.delete( ToyEntry.TABLE_NAME, selection, selectionArgs );
                break;
            default:
                throw new IllegalArgumentException( "Deletion is not supported for " + uri );
        }

        // If 1 or more rows were deleted, then notify all listeners that the data at the
        // given URI has changed
        if (rowsDeleted != 0) {
            getContext().getContentResolver().notifyChange( uri, null );
        }

        // Return the number of rows deleted
        return rowsDeleted;
    }

    /**
     * Returns the MIME type of data for the content URI.
     */
    @Override
    public String getType(Uri uri) {
        final int match = sUriMatcher.match( uri );
        switch (match) {
            case TOYS:
                return ToyEntry.CONTENT_LIST_TYPE;
            case TOY_ID:
                return ToyEntry.CONTENT_ITEM_TYPE;
            default:
                throw new IllegalStateException( "Unknown URI " + uri + " with match " + match );
        }
    }
}
