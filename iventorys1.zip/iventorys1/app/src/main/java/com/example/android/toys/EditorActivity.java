/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.toys;

import android.app.AlertDialog;
import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.android.toys.data.ToyContract.ToyEntry;

/**
 * Allows user to create a new toy or edit an existing one.
 */
public class EditorActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    /**
     * Identifier for the toydata loader
     */
    private static final int EXISTING_TOY_LOADER = 0;

    /**
     * Content URI for the existing toy(null if it's a new toy)
     */
    private Uri mCurrentToyUri;

    private int toyQty;
    private int supPhone;


    /**
     * EditText field to enter the toy's name
     */
    private EditText mNameEditText;

    /**
     * EditText field to enter the toy's price
     */
    private EditText mPriceEditText;

    /**
     * EditText field to enter the toy's quantity
     */
    private EditText mQtyEditText;

    /**
     * EditText field to enter the toy's warehouse
     */
    private Spinner mWarehouseSpinner;

    /**
     * EditText field to enter the provider's name
     */
    private EditText mProviderEditText;

    /**
     * EditText field to enter the provider's phone
     */
    private EditText mProviderPhoneEditText;


    /**
     * Button  to add more stock
     */
    private Button mMoreUnitsButton;

    /**
     * Button  to decrease stock
     */
    private Button mLessUnitsButton;

    /**
     * Button  to call provider
     */
    private Button mContactButton;


    /**
     * Gender of the pet. The possible valid values are in the ToyContract.java file:
     * {@link ToyEntry#WAREHOUSE_EASTCOAST}, {@link ToyEntry#WAREHOUSE_WESTCOAST}, or
     * {@link ToyEntry#WAREHOUSE_MIDWEST}.
     */
    private int mWarehouse = ToyEntry.WAREHOUSE_EASTCOAST;

    private boolean mToyHasChanged = false;

    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            mToyHasChanged = true;
            return false;
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_editor );

        Intent intent = getIntent();
        mCurrentToyUri = intent.getData();

        // Find all relevant views that we will need to read user input from
        mNameEditText = (EditText) findViewById( R.id.edit_toy_name );
        mPriceEditText = (EditText) findViewById( R.id.edit_toy_price );
        mQtyEditText = (EditText) findViewById( R.id.edit_toy_quantity );
        mWarehouseSpinner = (Spinner) findViewById( R.id.spinner_warehouse );
        mProviderEditText = (EditText) findViewById( R.id.edit_provider_name );
        mProviderPhoneEditText = (EditText) findViewById( R.id.edit_provider_phone );
        mMoreUnitsButton = (Button) findViewById( R.id.more_units );
        mLessUnitsButton = (Button) findViewById( R.id.less_units );
        mContactButton = (Button) findViewById( R.id.contact );

        if (mCurrentToyUri == null) {
            setTitle( getString( R.string.editor_activity_title_new_toy ) );
            mMoreUnitsButton.setVisibility( View.GONE );
            mLessUnitsButton.setVisibility( View.GONE );
            mContactButton.setVisibility( View.GONE );
            invalidateOptionsMenu();
        } else {
            // Otherwise this is an existing pet, so change app bar to say "Edit Pet"
            setTitle( getString( R.string.editor_activity_title_edit_toy ) );
            // Initialize a loader to read the toydata from the database
            // and display the current values in the editor
            getLoaderManager().initLoader( EXISTING_TOY_LOADER, null, this );
        }


        mNameEditText.setOnTouchListener( mTouchListener );
        mPriceEditText.setOnTouchListener( mTouchListener );
        mQtyEditText.setOnTouchListener( mTouchListener );
        mProviderEditText.setOnTouchListener( mTouchListener );
        mProviderPhoneEditText.setOnTouchListener( mTouchListener );
        mWarehouseSpinner.setOnTouchListener( mTouchListener );
        mLessUnitsButton.setOnTouchListener( mTouchListener );
        mLessUnitsButton.setOnTouchListener( mTouchListener );
        mContactButton.setOnTouchListener( mTouchListener );

        mMoreUnitsButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moreUnitsButton( v );
            }
        } );

        mLessUnitsButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lessUnitsButton( v );
            }
        } );

        //Button phoneButton = findViewById(R.id.phone_button);
        mContactButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = String.valueOf( supPhone );
                Intent intent = new Intent( Intent.ACTION_DIAL, Uri.fromParts( "tel", phone, null ) );
                startActivity( intent );
            }
        } );

        setupSpinner();
    }

    /**
     * Setup the dropdown spinner that allows the user to select the gender of the pet.
     */
    private void setupSpinner() {
        // Create adapter for spinner. The list options are from the String array it will use
        // the spinner will use the default layout
        ArrayAdapter warehouseSpinnerAdapter = ArrayAdapter.createFromResource( this, R.array.array_warehouse_options, android.R.layout.simple_spinner_item );

        // Specify dropdown layout style - simple list view with 1 item per line
        warehouseSpinnerAdapter.setDropDownViewResource( android.R.layout.simple_dropdown_item_1line );

        // Apply the adapter to the spinner
        mWarehouseSpinner.setAdapter( warehouseSpinnerAdapter );

        // Set the integer mSelected to the constant values
        mWarehouseSpinner.setOnItemSelectedListener( new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition( position );
                if (!TextUtils.isEmpty( selection )) {
                    if (selection.equals( getString( R.string.warehouse_west_coast ) )) {
                        mWarehouse = ToyEntry.WAREHOUSE_WESTCOAST;
                    } else if (selection.equals( getString( R.string.warehouse_midwest ) )) {
                        mWarehouse = ToyEntry.WAREHOUSE_MIDWEST;
                    } else {
                        mWarehouse = ToyEntry.WAREHOUSE_EASTCOAST;
                    }
                }
            }

            // Because AdapterView is an abstract class, onNothingSelected must be defined
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                mWarehouse = ToyEntry.WAREHOUSE_EASTCOAST;
            }
        } );
    }

    /**
     * Get user input from editor and save new toy into database.
     */
    private void savetToy() {
        // Read from input fields
        String nameString = mNameEditText.getText().toString().trim();
        String priceString = mPriceEditText.getText().toString().trim();
        String qtyString = mQtyEditText.getText().toString().trim();
        String providerString = mProviderEditText.getText().toString().trim();
        String providerPhoneString = mProviderPhoneEditText.getText().toString().trim();

        // Check if this is supposed to be a new toy
        // and check if all the fields in the editor are blank
        if (mCurrentToyUri == null &&
                TextUtils.isEmpty( nameString ) &&
                TextUtils.isEmpty( priceString ) &&
                TextUtils.isEmpty( qtyString ) &&
                mWarehouse == ToyEntry.WAREHOUSE_EASTCOAST &&
                TextUtils.isEmpty( providerString ) &&
                TextUtils.isEmpty( providerPhoneString )) {
            // Since no fields were modified, we can return early without creating a new pet.
            // No need to create ContentValues and no need to do any ContentProvider operations.
            return;
        }

        //required values
        ContentValues values = new ContentValues();
        if (TextUtils.isEmpty( nameString )) {
            Toast.makeText( this, getString( R.string.namereq ), Toast.LENGTH_SHORT ).show();
        } else {
            values.put( ToyEntry.COLUMN_TOY_NAME, nameString );
        }
        if (TextUtils.isEmpty( priceString )) {
            Toast.makeText( this, getString( R.string.pricereq ), Toast.LENGTH_SHORT ).show();
        } else {
            values.put( ToyEntry.COLUMN_TOY_PRICE, priceString );
        }
        if (TextUtils.isEmpty( qtyString )) {
            Toast.makeText( this, getString( R.string.qtyreq ), Toast.LENGTH_SHORT ).show();
        } else {
            values.put( ToyEntry.COLUMN_TOY_QTY, qtyString );
        }

        values.put( ToyEntry.COLUMN_TOY_WH, mWarehouse );

        if (TextUtils.isEmpty( providerString )) {
            Toast.makeText( this, getString( R.string.provname ), Toast.LENGTH_SHORT ).show();
        } else {
            values.put( ToyEntry.COLUMN_TOY_PROVIDER, providerString );
        }
        if (TextUtils.isEmpty( providerPhoneString )) {
            Toast.makeText( this, getString( R.string.provphone ), Toast.LENGTH_SHORT ).show();
        } else {
            values.put( ToyEntry.COLUMN_TOY_PHONE, providerPhoneString );
        }


        if(mCurrentToyUri == null) {

        Uri newUri = getContentResolver().insert( ToyEntry.CONTENT_URI, values );

        if (newUri == null) {
            // If the new content URI is null, then there was an error with insertion.
            Toast.makeText( this, getString( R.string.editor_insert_toy_failed ), Toast.LENGTH_SHORT ).show();
        } else {
            // Otherwise, the insertion was successful and we can display a toast.
            Toast.makeText( this, getString( R.string.editor_insert_toy_successful ), Toast.LENGTH_SHORT ).show();
        }
    } else

    {
        // Otherwise this is an EXISTING toy, so update the toywith content URI: mCurrentPetUri
        // and pass in the new ContentValues. Pass in null for the selection and selection args
        // because mCurrentPetUri will already identify the correct row in the database that
        // we want to modify.
        int rowsAffected = getContentResolver().update( mCurrentToyUri, values, null, null );

        // Show a toast message depending on whether or not the update was successful.
        if (rowsAffected == 0) {
            // If no rows were affected, then there was an error with the update.
            Toast.makeText( this, getString( R.string.editor_update_toy_failed ), Toast.LENGTH_SHORT ).show();
        } else {
            // Otherwise, the update was successful and we can display a toast.
            Toast.makeText( this, getString( R.string.editor_update_toy_successful ), Toast.LENGTH_SHORT ).show();
        }
    }

}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_editor.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate( R.menu.menu_editor, menu );
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu( menu );
        // If this is a new pet, hide the "Delete" menu item.
        if (mCurrentToyUri == null) {
            MenuItem menuItem = menu.findItem( R.id.action_delete );
            menuItem.setVisible( false );
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_save:
                // Save toyto database
                savetToy();
                // Exit activity
                finish();
                return true;
            // Respond to a click on the "Delete" menu option
            case R.id.action_delete:
                showDeleteConfirmationDialog();
                return true;
            // Respond to a click on the "Up" arrow button in the app bar
            case android.R.id.home:
                // Navigate back to parent activity (CatalogActivity)
                if (!mToyHasChanged) {
                    NavUtils.navigateUpFromSameTask( EditorActivity.this );
                    return true;
                }

                // Otherwise if there are unsaved changes, setup a dialog to warn the user.
                // Create a click listener to handle the user confirming that
                // changes should be discarded.
                DialogInterface.OnClickListener discardButtonClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // User clicked "Discard" button, navigate to parent activity.
                        NavUtils.navigateUpFromSameTask( EditorActivity.this );
                    }
                };

                // Show a dialog that notifies the user they have unsaved changes
                showUnsavedChangesDialog( discardButtonClickListener );
                return true;
        }
        return super.onOptionsItemSelected( item );
    }

    @Override
    public void onBackPressed() {
        // If the toy hasn't changed, continue with handling back button press
        if (!mToyHasChanged) {
            super.onBackPressed();
            return;
        }

        // Otherwise if there are unsaved changes, setup a dialog to warn the user.
        // Create a click listener to handle the user confirming that changes should be discarded.
        DialogInterface.OnClickListener discardButtonClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // User clicked "Discard" button, close the current activity.
                finish();
            }
        };

        // Show dialog that there are unsaved changes
        showUnsavedChangesDialog( discardButtonClickListener );
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle bundle) {

        String[] projection = {
                ToyEntry._ID,
                ToyEntry.COLUMN_TOY_NAME,
                ToyEntry.COLUMN_TOY_PRICE,
                ToyEntry.COLUMN_TOY_WH,
                ToyEntry.COLUMN_TOY_QTY,
                ToyEntry.COLUMN_TOY_PROVIDER,
                ToyEntry.COLUMN_TOY_PHONE
        };

        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader( this, ToyEntry.CONTENT_URI,   // The CONTENT URI of the TOYS table
                projection,            // The columns to return for each row
                null,                  // selection criteria
                null,                  // selction criteria
                null );                   // The sort order
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        // Bail early if the cursor is null or there is less than 1 row in the cursor
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }

        // Proceed with moving to the first row of the cursor and reading data from it
        // (This should be the only row in the cursor)
        if (cursor.moveToFirst()) {
            // Find the columns of toy attributes that we're interested in
            int nameColumnIndex = cursor.getColumnIndex( ToyEntry.COLUMN_TOY_NAME );
            int PriceColumnIndex = cursor.getColumnIndex( ToyEntry.COLUMN_TOY_PRICE );
            int warehouseColumnIndex = cursor.getColumnIndex( ToyEntry.COLUMN_TOY_WH );
            int quantityColumnIndex = cursor.getColumnIndex( ToyEntry.COLUMN_TOY_QTY );
            int providerColumnIndex = cursor.getColumnIndex( ToyEntry.COLUMN_TOY_PROVIDER );
            int phoneColumnIndex = cursor.getColumnIndex( ToyEntry.COLUMN_TOY_PHONE );


            // Extract out the value from the Cursor for the given column index
            String name = cursor.getString( nameColumnIndex );
            int price = cursor.getInt( PriceColumnIndex );
            int warehouse = cursor.getInt( warehouseColumnIndex );
            int qty = cursor.getInt( quantityColumnIndex );
            toyQty = qty;
            String provider = cursor.getString( providerColumnIndex );
            int phone = cursor.getInt( phoneColumnIndex );
            supPhone = phone;


            // Update the views on the screen with the values from the database
            mNameEditText.setText( name );
            mPriceEditText.setText( Integer.toString(price ));
            //mPriceEditText.setText(price);

            mQtyEditText.setText( Integer.toString(qty) );
            mProviderEditText.setText( provider );
            mProviderPhoneEditText.setText( Integer.toString(phone) );


            // warehouse is a dropdown spinner, so map the constant value from the database
            // into one of the dropdown options (0 is EastCoast, 1 is WestCoast, 2 is Midwest).
            // Then call setSelection() so that option is displayed on screen as the current selection.
            switch (warehouse) {
                case ToyEntry.WAREHOUSE_WESTCOAST:
                    mWarehouseSpinner.setSelection(1);
                    break;
                case ToyEntry.WAREHOUSE_MIDWEST:
                    mWarehouseSpinner.setSelection(2);
                    break;
                default:
                    mWarehouseSpinner.setSelection(0);
                    break;
            }
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mNameEditText.setText( "" );
        mPriceEditText.setText( "" );
        mQtyEditText.setText( "" );
        mProviderEditText.setText( "" );
        mProviderPhoneEditText.setText( "" );
        mWarehouseSpinner.setSelection( 0 ); //east coast warehouse
    }

    private void showUnsavedChangesDialog(DialogInterface.OnClickListener discardButtonClickListener) {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder( this );
        builder.setMessage( R.string.unsaved_changes_dialog_msg );
        builder.setPositiveButton( R.string.discard, discardButtonClickListener );
        builder.setNegativeButton( R.string.keep_editing, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Keep editing" button, so dismiss the dialog
                // and continue editing the pet.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        } );

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }

    private void showDeleteConfirmationDialog() {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the postivie and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder( this );
        builder.setMessage( R.string.delete_dialog_msg );
        builder.setPositiveButton( R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Delete" button, so delete the pet.
                deleteToy();
            }
        } );
        builder.setNegativeButton( R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Cancel" button, so dismiss the dialog
                // and continue editing the pet.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        } );

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    /**
     * Perform the deletion of the toyin the database.
     */
    private void deleteToy() {
        // Only perform the delete if this is an existing pet.
        if (mCurrentToyUri != null) {
            // Call the ContentResolver to delete the toyat the given content URI.
            // Pass in null for the selection and selection args because the mCurrentPetUri
            // content URI already identifies the toythat we want.
            int rowsDeleted = getContentResolver().delete( mCurrentToyUri, null, null );

            // Show a toast message depending on whether or not the delete was successful.
            if (rowsDeleted == 0) {
                // If no rows were deleted, then there was an error with the delete.
                Toast.makeText( this, getString( R.string.editor_delete_pet_failed ), Toast.LENGTH_SHORT ).show();
            } else {
                // Otherwise, the delete was successful and we can display a toast.
                Toast.makeText( this, getString( R.string.editor_delete_pet_successful ), Toast.LENGTH_SHORT ).show();
            }
        }
        // Close the activity
        finish();

    }

    public void moreUnitsButton(View view) {
        toyQty++;
        displayQuantity();
    }

    public void lessUnitsButton(View view) {
        if (toyQty == 0) {
            Toast.makeText( this, R.string.qtyzero, Toast.LENGTH_SHORT ).show();
        } else {
            toyQty--;
            displayQuantity();
        }
    }


    public void contactButton(View view) {
        if (toyQty == 0) {
            Toast.makeText( this, R.string.qtyzero, Toast.LENGTH_SHORT ).show();
        } else {
            toyQty--;
            displayQuantity();
        }
    }


    public void displayQuantity() {
        mQtyEditText.setText( String.valueOf( toyQty ) );
    }
}