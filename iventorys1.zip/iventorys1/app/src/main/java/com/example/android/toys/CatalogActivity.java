/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.toys;


import android.app.LoaderManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.android.toys.data.ToyContract.ToyEntry;

/**
 * Displays list of toys that were entered and stored in the app.
 */
public class CatalogActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    public static final String LOG_TAG = CatalogActivity.class.getSimpleName();

    private static final int TOY_LOADER = 0;
    ToyCursorAdapter mCursorAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_catalog );

        // Setup FAB to open EditorActivity
        FloatingActionButton fab = (FloatingActionButton) findViewById( R.id.fab );
        fab.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( CatalogActivity.this, EditorActivity.class );
                startActivity( intent );
            }
        } );



        // Find the ListView which will be populated with the toy data
        ListView toyListView = (ListView) findViewById(R.id.list);

        // Find and set empty view on the ListView, so that it only shows when the list has 0 items.
        View emptyView = findViewById(R.id.empty_view);
        toyListView.setEmptyView(emptyView);

        mCursorAdapter = new ToyCursorAdapter(this, null);
        toyListView.setAdapter(mCursorAdapter);
// Setup the item click listener
        toyListView.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                // Create new intent to go to {@link EditorActivity}
                Intent intent = new Intent(CatalogActivity.this, EditorActivity.class);


                Uri currentToyUri = ContentUris.withAppendedId(ToyEntry.CONTENT_URI, id);
                Log.i(LOG_TAG, "Current URI: " + currentToyUri );


                // Set the URI on the data field of the intent
                intent.setData( currentToyUri );

                // Launch the {@link EditorActivity} to display the data for the current toy.
                startActivity(intent);
            }
        });
        // Kick off the loader
        getLoaderManager().initLoader(TOY_LOADER, null, this);


    }



    /**
     * Helper method to insert hardcoded toy data into the database. For debugging purposes only.
     */
    private void insertToy() {

        ContentValues values = new ContentValues();
        values.put( ToyEntry.COLUMN_TOY_NAME, "GI JOE" );
        values.put( ToyEntry.COLUMN_TOY_PRICE, "29" );
        values.put( ToyEntry.COLUMN_TOY_WH, ToyEntry.WAREHOUSE_WESTCOAST );
        values.put( ToyEntry.COLUMN_TOY_QTY, 100 );
        values.put( ToyEntry.COLUMN_TOY_PROVIDER, "Alibaba" );
        values.put( ToyEntry.COLUMN_TOY_PHONE, 5406869 );


        // Insert a new row for GIJOE in the database, returning the ID of that new row.
        // The first argument for db.insert() is the toys table name.
        // The second argument provides the name of a column in which the framework
        // can insert NULL in the event that the ContentValues is empty (if
        // this is set to "null", then the framework will not insert a row when
        // there are no values).
        // The third argument is the ContentValues object containing the info for Toto.
        Uri newUri = getContentResolver().insert(ToyEntry.CONTENT_URI, values);

    }
    private void deleteAllPets() {
        int rowsDeleted = getContentResolver().delete(ToyEntry.CONTENT_URI, null, null);
        Log.v("CatalogActivity", rowsDeleted + " rows deleted from toy database");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu options from the res/menu/menu_catalog.xml file.
        // This adds menu items to the app bar.
        getMenuInflater().inflate( R.menu.menu_catalog, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Insert dummy data" menu option
            case R.id.action_insert_dummy_data:
                insertToy();
                return true;
            // Respond to a click on the "Delete all entries" menu option
            case R.id.action_delete_all_entries:
                deleteAllPets();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        String[] projection = {
                ToyEntry._ID,
                ToyEntry.COLUMN_TOY_NAME,
                ToyEntry.COLUMN_TOY_PRICE,
                ToyEntry.COLUMN_TOY_WH,
                ToyEntry.COLUMN_TOY_QTY,
                ToyEntry.COLUMN_TOY_PROVIDER,
                ToyEntry.COLUMN_TOY_PHONE};

        // Perform a query on the toys table
        //Use the {@Link ToyEntry#CONTENT_URI} to access the toy data
        return new CursorLoader(this,
                ToyEntry.CONTENT_URI,   // The CONTENT URI of the TOYS table
                projection,            // The columns to return for each row
                null,                  // selection criteria
                null,                  // selction criteria
                null );                   // The sort order
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mCursorAdapter.swapCursor(data);

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mCursorAdapter.swapCursor(null);

        }


}
